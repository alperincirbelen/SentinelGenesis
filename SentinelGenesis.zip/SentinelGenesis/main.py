from core.sentinel import SentinelGenesis

if __name__ == "__main__":
    # KENDİ MASTER ID'NİZİ YAZIN (rastgele sayı/harf kombinasyonu)
    ai = SentinelGenesis(master_id="M4ST3R-8D1U-XK9P")
    ai.run()