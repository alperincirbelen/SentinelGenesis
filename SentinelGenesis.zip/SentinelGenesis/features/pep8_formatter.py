class Feature:
    def execute(self, code: str) -> str:
        try:
            # Pydroid 3 için özel import
            import sys
            sys.path.append('/data/user/0/ru.iiec.pydroid3/files/aarch64-linux-android/lib/python3.11/site-packages')
            import autopep8
            
            formatted = autopep8.fix_code(
                code,
                options={
                    'aggressive': 2,
                    'max_line_length': 120,
                    'ignore': ['E402', 'W503']
                }
            )
            return formatted
        except Exception as e:
            return self.simple_format(code) + f"\n# Formatlama hatası: {str(e)}"

    def simple_format(self, code: str) -> str:
        """Basit formatlama (autopep8 olmadan)"""
        # Basit düzeltmeler
        code = code.replace(";", "\n")
        code = code.replace("){", "):\n{")
        code = code.replace("):", "):\n    ")
        return code