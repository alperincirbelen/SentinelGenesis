class Feature:
    def execute(self, function_code: str) -> str:
        if "def " in function_code:
            # Fonksiyon adını al
            func_line = function_code.split('\n')[0]
            func_name = func_line.split('def ')[1].split('(')[0].strip()
            
            # Parametreleri al
            params = []
            if '(' in func_line and ')' in func_line:
                params_part = func_line.split('(')[1].split(')')[0]
                params = [param.strip().split('=')[0] for param in params_part.split(',') if param.strip()]
            
            # Docstring oluştur
            docstring = f'    """\n    {func_name} fonksiyonunun açıklaması.\n\n    Parametreler:'
            for param in params:
                docstring += f'\n    {param}: Açıklama'
            docstring += '\n\n    Dönüş: Açıklama\n    """'
            
            # Docstring'i ekle
            return function_code.replace("):", "):\n" + docstring)
        return function_code