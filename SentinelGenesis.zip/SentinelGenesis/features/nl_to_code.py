import random
import re

class Feature:
    def execute(self, prompt: str) -> str:
        prompt = prompt.lower()
        
        # Print komutu
        if any(k in prompt for k in ["print", "output", "show", "display"]):
            text = self.extract_text(prompt)
            return f"print('{text}')"
        
        # Döngü komutu
        elif any(k in prompt for k in ["loop", "for", "repeat"]):
            count = self.extract_number(prompt) or 5
            var = random.choice(['i', 'j', 'x'])
            return f"for {var} in range({count}):\n    print({var})"
        
        # Koşul komutu
        elif any(k in prompt for k in ["if", "condition", "check"]):
            var = random.choice(['x', 'y', 'value'])
            return f"{var} = 10\nif {var} > 5:\n    print('Greater than 5')"
        
        # Fonksiyon oluşturma
        elif any(k in prompt for k in ["function", "def", "create function"]):
            func_name = self.extract_function_name(prompt) or "my_function"
            return f"def {func_name}():\n    print('Function executed')"
        
        # Liste işlemleri
        elif any(k in prompt for k in ["list", "array", "collection"]):
            return "my_list = [1, 2, 3]\nfor item in my_list:\n    print(item)"
        
        else:
            return "# Couldn't generate code. Try one of these:\n#  - Print something\n#  - Create a loop\n#  - Make a condition\n#  - Define a function\n#  - Work with a list"

    def extract_text(self, prompt):
        # Tırnak içindeki metni çıkar
        if '"' in prompt:
            return re.search(r'"([^"]+)"', prompt).group(1)
        elif "'" in prompt:
            return re.search(r"'([^']+)'", prompt).group(1)
        return "Hello World"

    def extract_number(self, prompt):
        # Sayıları çıkar
        numbers = re.findall(r'\d+', prompt)
        return int(numbers[0]) if numbers else None

    def extract_function_name(self, prompt):
        # Fonksiyon ismini çıkar
        if "named" in prompt:
            return prompt.split("named")[1].strip().split()[0]
        return None