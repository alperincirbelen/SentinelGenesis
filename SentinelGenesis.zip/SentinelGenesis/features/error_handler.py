class Feature:
    def execute(self, code: str) -> str:
        common_fixes = {
            "for i in range(10)": "for i in range(10):",
            "print 'hello'": "print('hello')",
            "if x = 5:": "if x == 5:",
            "def my_func()": "def my_func():",
            "els:": "else:",
            "retrun": "return"
        }
        for error, fix in common_fixes.items():
            if error in code:
                return code.replace(error, fix)
        return code 