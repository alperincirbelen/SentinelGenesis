import re

class Feature:
    def execute(self, prompt: str) -> str:
        prompt = prompt.lower()
        
        # Sınıf ismini çıkar
        class_name_match = re.search(r'class named (\w+)|class (\w+)', prompt)
        if not class_name_match:
            return "# Error: Could not find class name in the prompt."
        
        class_name = class_name_match.group(1) if class_name_match.group(1) else class_name_match.group(2)
        class_name = class_name.capitalize()
        
        # Özellikleri çıkar
        attributes = []
        attr_match = re.search(r'attributes?:\s*((?:\w+,\s*)*\w+)', prompt)
        if attr_match:
            attributes = [attr.strip() for attr in attr_match.group(1).split(',')]
        
        # Metotları çıkar
        methods = []
        method_match = re.search(r'methods?:\s*((?:\w+,\s*)*\w+)', prompt)
        if method_match:
            methods = [method.strip() for method in method_match.group(1).split(',')]
        
        # Sınıf kodunu oluştur
        class_code = f"class {class_name}:\n"
        
        # __init__ metodu
        if attributes:
            class_code += f"    def __init__(self, {', '.join(attributes)}):\n"
            for attr in attributes:
                class_code += f"        self.{attr} = {attr}\n"
            class_code += "\n"
        
        # Diğer metotlar
        for method in methods:
            class_code += f"    def {method}(self):\n"
            class_code += f"        # Implement your method here\n"
            class_code += f"        pass\n\n"
        
        return class_code.strip() 