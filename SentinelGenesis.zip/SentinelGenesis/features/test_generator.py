class Feature:
    def execute(self, function_code: str) -> str:
        if "def " in function_code:
            func_line = function_code.split('\n')[0]
            func_name = func_line.split('def ')[1].split('(')[0].strip()
            
            return f"def test_{func_name}():\n" \
                   f"    \"\"\"{func_name} fonksiyonu için test senaryoları\"\"\"\n" \
                   f"    # Test 1: Temel test\n" \
                   f"    # result = {func_name}()\n" \
                   f"    # assert result == expected_value\n\n" \
                   f"    # Test 2: Edge case\n" \
                   f"    # ...\n" \
                   f"    pass"
        return "# Fonksiyon bulunamadı"