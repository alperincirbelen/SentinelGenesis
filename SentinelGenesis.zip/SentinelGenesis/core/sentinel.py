import importlib

class SentinelGenesis:
    def __init__(self, master_id):
        self.master_id = master_id
        self.features = {}
        print(f"Sentinel Genesis Initialized. Master ID: {master_id}")
    
    def load_feature(self, feature_name):
        if feature_name not in self.features:
            try:
                module = importlib.import_module(f"features.{feature_name}")
                self.features[feature_name] = module.Feature()
                print(f"Loaded feature: {feature_name}")
            except ImportError:
                print(f"⛔ Error: Feature '{feature_name}' not found")
                return None
        return self.features[feature_name]
    
    def run(self):
        print("CLI activated. Type 'help' for commands or 'exit' to quit.")
        while True:
            try:
                command = input(">>> ").strip()
                
                if command == "exit":
                    print("System shutdown...")
                    break
                    
                elif command == "help":
                    print("Available commands:")
                    print("  generate <prompt>       - Generate code from natural language")
                    print("  generate_class <prompt> - Generate a class from natural language")
                    print("  format <code>           - Format code to PEP8 standards")
                    print("  fix <code>              - Fix common errors in code")
                    print("  docstring <code>        - Add docstring to function")
                    print("  test <function>         - Generate test for function")
                    print("  list_features           - Show available features")
                    print("  exit                    - Close the system")
                
                elif command == "list_features":
                    print("Installed features:")
                    print("  - nl_to_code : Natural Language to Code Generation")
                    print("  - class_generator : Class-Based Code Generation")
                    print("  - pep8_formatter : PEP8 Code Formatting")
                    print("  - error_handler : Common Error Fixer")
                    print("  - docstring_generator : Docstring Generator")
                    print("  - test_generator : Test Code Generator")
                
                elif command.startswith("generate "):
                    prompt = command[9:]
                    feature = self.load_feature("nl_to_code")
                    if feature:
                        result = feature.execute(prompt)
                        print(f"Generated Code:\n```python\n{result}\n```")
                
                elif command.startswith("generate_class "):
                    prompt = command[15:]
                    feature = self.load_feature("class_generator")
                    if feature:
                        result = feature.execute(prompt)
                        print(f"Generated Class:\n```python\n{result}\n```")
                
                elif command.startswith("format "):
                    code = command[6:]
                    feature = self.load_feature("pep8_formatter")
                    if feature:
                        result = feature.execute(code)
                        print(f"Formatted Code:\n```python\n{result}\n```")
                
                elif command.startswith("fix "):
                    code = command[4:]
                    feature = self.load_feature("error_handler")
                    if feature:
                        result = feature.execute(code)
                        print(f"Fixed Code:\n```python\n{result}\n```")
                
                elif command.startswith("docstring "):
                    code = command[10:]
                    feature = self.load_feature("docstring_generator")
                    if feature:
                        result = feature.execute(code)
                        print(f"Documented Function:\n```python\n{result}\n```")
                
                elif command.startswith("test "):
                    code = command[5:]
                    feature = self.load_feature("test_generator")
                    if feature:
                        result = feature.execute(code)
                        print(f"Test Code:\n```python\n{result}\n```")
                
                else:
                    print(f"Unknown command: {command}. Type 'help' for available commands.")
            
            except Exception as e:
                print(f"⚠️ Error: {str(e)}")